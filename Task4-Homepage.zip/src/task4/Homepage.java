package task4;

import javax.swing.*;

public class Homepage extends JFrame {

    public Homepage() {
        setTitle("Homepage");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel titleLabel = new JLabel("Welcome to the Homepage", SwingConstants.CENTER);
        titleLabel.setFont(titleLabel.getFont().deriveFont(20f));

        JLabel greetingLabel = new JLabel("Hello, User!", SwingConstants.CENTER);

        JButton viewProfileButton = new JButton("View Profile");
        JButton settingsButton = new JButton("Settings");
        JButton logoutButton = new JButton("Logout");

        logoutButton.addActionListener(e -> {
            dispose();
            new LoginForm().setVisible(true);
        });

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.add(titleLabel);
        panel.add(Box.createVerticalStrut(10));
        panel.add(greetingLabel);
        panel.add(Box.createVerticalStrut(20));
        panel.add(viewProfileButton);
        panel.add(settingsButton);
        panel.add(logoutButton);

        add(panel);
    }

    public static void main(String[] args) {
        new Homepage().setVisible(true);
    }
}

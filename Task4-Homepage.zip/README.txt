Task 4: Java + MySQL + GUI Project

Steps to Run:
1. Open this project in NetBeans.
2. Make sure MySQL is installed and running.
3. Create a database (e.g., task4db).
4. Edit 'DatabaseConnection.java' and update:
   - your_database_name
   - your_mysql_username
   - your_mysql_password
5. Right-click Homepage.java and choose "Run File".

Enjoy!

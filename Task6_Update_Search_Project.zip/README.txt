Task 6 Project: Update and Search Products/Buyers

Setup Instructions:
1. Import add_sample_data.sql
2. Update db/config.php with your DB credentials
3. Run via localhost
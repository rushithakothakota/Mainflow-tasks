CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    category VARCHAR(100),
    price DECIMAL(10,2)
);
INSERT INTO products (name, category, price) VALUES ('Laptop', 'Electronics', 599.99);
<?php include '../db/connect.php'; ?>
<form method="post">
  Name: <input type="text" name="name" required><br>
  Category: <input type="text" name="category"><br>
  Price: <input type="number" name="price" step="0.01"><br>
  Quantity: <input type="number" name="quantity"><br>
  Description: <textarea name="description"></textarea><br>
  <input type="submit" name="submit" value="Add Product">
</form>

<?php
if (isset($_POST['submit'])) {
    $stmt = $conn->prepare("INSERT INTO products (name, category, price, quantity, description) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdss", $_POST['name'], $_POST['category'], $_POST['price'], $_POST['quantity'], $_POST['description']);
    if ($stmt->execute()) {
        echo "Product added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>
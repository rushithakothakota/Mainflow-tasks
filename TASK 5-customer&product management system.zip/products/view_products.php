<?php include '../db/connect.php'; ?>
<h2>Products List</h2>
<table border="1">
<tr><th>ID</th><th>Name</th><th>Category</th><th>Price</th><th>Quantity</th><th>Description</th><th>Action</th></tr>
<?php
$result = $conn->query("SELECT * FROM products");
while($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$row['id']}</td><td>{$row['name']}</td><td>{$row['category']}</td>
        <td>{$row['price']}</td><td>{$row['quantity']}</td><td>{$row['description']}</td>
        <td><a href='delete_product.php?id={$row['id']}' onclick='return confirm(\"Delete this product?\")'>Delete</a></td>
    </tr>";
}
?>
</table>
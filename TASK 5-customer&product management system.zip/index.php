<h1>Task 5: Product and Buyer Management</h1>
<ul>
  <li><a href="products/add_product.php">Add Product</a></li>
  <li><a href="products/view_products.php">View Products</a></li>
  <li><a href="buyers/add_buyer.php">Add Buyer</a></li>
  <li><a href="buyers/view_buyers.php">View Buyers</a></li>
</ul>
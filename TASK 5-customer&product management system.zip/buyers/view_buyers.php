<?php include '../db/connect.php'; ?>
<h2>Buyers List</h2>
<table border="1">
<tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Address</th><th>Action</th></tr>
<?php
$result = $conn->query("SELECT * FROM buyers");
while($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$row['id']}</td><td>{$row['name']}</td><td>{$row['email']}</td>
        <td>{$row['phone']}</td><td>{$row['address']}</td>
        <td><a href='delete_buyer.php?id={$row['id']}' onclick='return confirm(\"Delete this buyer?\")'>Delete</a></td>
    </tr>";
}
?>
</table>
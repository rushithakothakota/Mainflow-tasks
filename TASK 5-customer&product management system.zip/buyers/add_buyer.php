<?php include '../db/connect.php'; ?>
<form method="post">
  Name: <input type="text" name="name" required><br>
  Email: <input type="email" name="email"><br>
  Phone Number: <input type="text" name="phone"><br>
  Address: <textarea name="address"></textarea><br>
  <input type="submit" name="submit" value="Add Buyer">
</form>

<?php
if (isset($_POST['submit'])) {
    $stmt = $conn->prepare("INSERT INTO buyers (name, email, phone, address) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $_POST['name'], $_POST['email'], $_POST['phone'], $_POST['address']);
    if ($stmt->execute()) {
        echo "Buyer added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>